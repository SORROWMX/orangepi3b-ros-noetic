
"use strict";

let SelfTest = require('./SelfTest.js')
let AddDiagnostics = require('./AddDiagnostics.js')

module.exports = {
  SelfTest: SelfTest,
  AddDiagnostics: AddDiagnostics,
};
