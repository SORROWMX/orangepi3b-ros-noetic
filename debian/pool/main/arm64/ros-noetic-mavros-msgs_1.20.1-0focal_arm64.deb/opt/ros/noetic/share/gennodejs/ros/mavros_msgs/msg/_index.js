
"use strict";

let GPSINPUT = require('./GPSINPUT.js');
let HilSensor = require('./HilSensor.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let LogEntry = require('./LogEntry.js');
let State = require('./State.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let Tunnel = require('./Tunnel.js');
let PlayTuneV2 = require('./PlayTuneV2.js');
let PositionTarget = require('./PositionTarget.js');
let Vibration = require('./Vibration.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let HilGPS = require('./HilGPS.js');
let Trajectory = require('./Trajectory.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let VehicleInfo = require('./VehicleInfo.js');
let Altitude = require('./Altitude.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let Waypoint = require('./Waypoint.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let ParamValue = require('./ParamValue.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let GPSRTK = require('./GPSRTK.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');
let LogData = require('./LogData.js');
let ManualControl = require('./ManualControl.js');
let FileEntry = require('./FileEntry.js');
let TerrainReport = require('./TerrainReport.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let CommandCode = require('./CommandCode.js');
let ESCInfo = require('./ESCInfo.js');
let StatusText = require('./StatusText.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let MountControl = require('./MountControl.js');
let RadioStatus = require('./RadioStatus.js');
let DebugValue = require('./DebugValue.js');
let GPSRAW = require('./GPSRAW.js');
let Param = require('./Param.js');
let Mavlink = require('./Mavlink.js');
let HomePosition = require('./HomePosition.js');
let RTCM = require('./RTCM.js');
let RCIn = require('./RCIn.js');
let BatteryStatus = require('./BatteryStatus.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let RTKBaseline = require('./RTKBaseline.js');
let VFR_HUD = require('./VFR_HUD.js');
let LandingTarget = require('./LandingTarget.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let SysStatus = require('./SysStatus.js');
let CellularStatus = require('./CellularStatus.js');
let Thrust = require('./Thrust.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let WaypointList = require('./WaypointList.js');
let HilControls = require('./HilControls.js');
let ActuatorControl = require('./ActuatorControl.js');
let ESCStatus = require('./ESCStatus.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let ExtendedState = require('./ExtendedState.js');
let RCOut = require('./RCOut.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let WaypointReached = require('./WaypointReached.js');

module.exports = {
  GPSINPUT: GPSINPUT,
  HilSensor: HilSensor,
  ESCTelemetryItem: ESCTelemetryItem,
  LogEntry: LogEntry,
  State: State,
  ESCInfoItem: ESCInfoItem,
  Tunnel: Tunnel,
  PlayTuneV2: PlayTuneV2,
  PositionTarget: PositionTarget,
  Vibration: Vibration,
  AttitudeTarget: AttitudeTarget,
  HilGPS: HilGPS,
  Trajectory: Trajectory,
  OverrideRCIn: OverrideRCIn,
  VehicleInfo: VehicleInfo,
  Altitude: Altitude,
  GlobalPositionTarget: GlobalPositionTarget,
  ADSBVehicle: ADSBVehicle,
  Waypoint: Waypoint,
  HilActuatorControls: HilActuatorControls,
  ParamValue: ParamValue,
  EstimatorStatus: EstimatorStatus,
  GPSRTK: GPSRTK,
  CamIMUStamp: CamIMUStamp,
  CameraImageCaptured: CameraImageCaptured,
  LogData: LogData,
  ManualControl: ManualControl,
  FileEntry: FileEntry,
  TerrainReport: TerrainReport,
  NavControllerOutput: NavControllerOutput,
  CommandCode: CommandCode,
  ESCInfo: ESCInfo,
  StatusText: StatusText,
  ESCStatusItem: ESCStatusItem,
  MagnetometerReporter: MagnetometerReporter,
  WheelOdomStamped: WheelOdomStamped,
  MountControl: MountControl,
  RadioStatus: RadioStatus,
  DebugValue: DebugValue,
  GPSRAW: GPSRAW,
  Param: Param,
  Mavlink: Mavlink,
  HomePosition: HomePosition,
  RTCM: RTCM,
  RCIn: RCIn,
  BatteryStatus: BatteryStatus,
  ESCTelemetry: ESCTelemetry,
  OnboardComputerStatus: OnboardComputerStatus,
  RTKBaseline: RTKBaseline,
  VFR_HUD: VFR_HUD,
  LandingTarget: LandingTarget,
  TimesyncStatus: TimesyncStatus,
  SysStatus: SysStatus,
  CellularStatus: CellularStatus,
  Thrust: Thrust,
  CompanionProcessStatus: CompanionProcessStatus,
  WaypointList: WaypointList,
  HilControls: HilControls,
  ActuatorControl: ActuatorControl,
  ESCStatus: ESCStatus,
  HilStateQuaternion: HilStateQuaternion,
  ExtendedState: ExtendedState,
  RCOut: RCOut,
  OpticalFlowRad: OpticalFlowRad,
  WaypointReached: WaypointReached,
};
