
"use strict";

let TestRequestOnly = require('./TestRequestOnly.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestNestedService = require('./TestNestedService.js')
let TestEmpty = require('./TestEmpty.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let SendBytes = require('./SendBytes.js')
let AddTwoInts = require('./AddTwoInts.js')

module.exports = {
  TestRequestOnly: TestRequestOnly,
  TestResponseOnly: TestResponseOnly,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestNestedService: TestNestedService,
  TestEmpty: TestEmpty,
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestArrayRequest: TestArrayRequest,
  TestRequestAndResponse: TestRequestAndResponse,
  SendBytes: SendBytes,
  AddTwoInts: AddTwoInts,
};
