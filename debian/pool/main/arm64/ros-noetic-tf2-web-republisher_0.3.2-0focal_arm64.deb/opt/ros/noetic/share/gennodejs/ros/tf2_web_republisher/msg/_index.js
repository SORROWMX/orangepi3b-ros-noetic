
"use strict";

let TFSubscriptionResult = require('./TFSubscriptionResult.js');
let TFSubscriptionActionResult = require('./TFSubscriptionActionResult.js');
let TFSubscriptionFeedback = require('./TFSubscriptionFeedback.js');
let TFSubscriptionAction = require('./TFSubscriptionAction.js');
let TFSubscriptionActionFeedback = require('./TFSubscriptionActionFeedback.js');
let TFSubscriptionActionGoal = require('./TFSubscriptionActionGoal.js');
let TFSubscriptionGoal = require('./TFSubscriptionGoal.js');
let TFArray = require('./TFArray.js');

module.exports = {
  TFSubscriptionResult: TFSubscriptionResult,
  TFSubscriptionActionResult: TFSubscriptionActionResult,
  TFSubscriptionFeedback: TFSubscriptionFeedback,
  TFSubscriptionAction: TFSubscriptionAction,
  TFSubscriptionActionFeedback: TFSubscriptionActionFeedback,
  TFSubscriptionActionGoal: TFSubscriptionActionGoal,
  TFSubscriptionGoal: TFSubscriptionGoal,
  TFArray: TFArray,
};
