# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${rosgraph_msgs_PREFIX}/share/rosgraph_msgs" "msg" rosgraph_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(rosgraph_msgs_MSG_DEPENDENCIES std_msgs)
