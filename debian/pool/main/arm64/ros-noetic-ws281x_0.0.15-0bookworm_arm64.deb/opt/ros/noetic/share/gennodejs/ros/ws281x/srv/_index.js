
"use strict";

let SetGamma = require('./SetGamma.js')

module.exports = {
  SetGamma: SetGamma,
};
