(cl:in-package coptra_blocks-srv)
(cl:export '(CODE-VAL
          CODE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))