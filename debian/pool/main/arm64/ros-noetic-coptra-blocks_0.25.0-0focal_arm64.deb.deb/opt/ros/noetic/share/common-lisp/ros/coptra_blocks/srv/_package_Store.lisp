(cl:in-package coptra_blocks-srv)
(cl:export '(NAME-VAL
          NAME
          PROGRAM-VAL
          PROGRAM
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))