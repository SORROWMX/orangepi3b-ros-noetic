set(coptra_blocks_MESSAGE_FILES "msg/Prompt.msg")
set(coptra_blocks_SERVICE_FILES "srv/Run.srv;srv/Load.srv;srv/Store.srv")
