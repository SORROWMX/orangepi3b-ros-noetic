(cl:defpackage coptra_blocks-msg
  (:use )
  (:export
   "<PROMPT>"
   "PROMPT"
  ))

