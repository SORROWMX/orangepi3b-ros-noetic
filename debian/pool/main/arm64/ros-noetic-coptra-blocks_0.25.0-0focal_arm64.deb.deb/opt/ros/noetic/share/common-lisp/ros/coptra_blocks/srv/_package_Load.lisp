(cl:in-package coptra_blocks-srv)
(cl:export '(SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
          NAMES-VAL
          NAMES
          PROGRAMS-VAL
          PROGRAMS
))