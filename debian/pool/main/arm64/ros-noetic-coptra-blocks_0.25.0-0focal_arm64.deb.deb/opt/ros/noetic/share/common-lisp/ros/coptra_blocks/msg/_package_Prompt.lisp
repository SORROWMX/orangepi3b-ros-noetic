(cl:in-package coptra_blocks-msg)
(cl:export '(MESSAGE-VAL
          MESSAGE
          ID-VAL
          ID
))