# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${coptra_blocks_DIR}/.." "msg" coptra_blocks_MSG_INCLUDE_DIRS UNIQUE)
set(coptra_blocks_MSG_DEPENDENCIES )
