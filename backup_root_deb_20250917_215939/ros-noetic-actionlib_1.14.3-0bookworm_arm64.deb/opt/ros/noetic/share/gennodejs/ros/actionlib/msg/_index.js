
"use strict";

let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestActionResult = require('./TestActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestAction = require('./TestAction.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestResult = require('./TestResult.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestActionFeedback = require('./TestActionFeedback.js');

module.exports = {
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TwoIntsGoal: TwoIntsGoal,
  TestFeedback: TestFeedback,
  TwoIntsResult: TwoIntsResult,
  TestActionResult: TestActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
  TestAction: TestAction,
  TestGoal: TestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestAction: TestRequestAction,
  TestRequestFeedback: TestRequestFeedback,
  TestResult: TestResult,
  TwoIntsAction: TwoIntsAction,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestActionGoal: TestActionGoal,
  TestRequestResult: TestRequestResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestGoal: TestRequestGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestActionFeedback: TestActionFeedback,
};
