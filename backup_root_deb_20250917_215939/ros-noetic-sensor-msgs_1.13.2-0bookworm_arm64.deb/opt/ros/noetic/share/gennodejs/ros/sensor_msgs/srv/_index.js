
"use strict";

let SetCameraInfo = require('./SetCameraInfo.js')

module.exports = {
  SetCameraInfo: SetCameraInfo,
};
